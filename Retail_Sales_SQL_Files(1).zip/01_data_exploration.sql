-- DATA EXPLORATION

SELECT COUNT(DISTINCT "Order ID") AS Total_Orders FROM superstore;
SELECT COUNT(DISTINCT "Customer ID") AS Total_Customers FROM superstore;
SELECT MIN("Order Date") AS First_Order, MAX("Order Date") AS Last_Order FROM superstore;
SELECT SUM(Sales) AS Total_Sales FROM superstore;
SELECT SUM(Profit) AS Total_Profit FROM superstore;
SELECT (SUM(Profit)*100.0/SUM(Sales)) AS Profit_Margin FROM superstore;
SELECT SUM(Sales)/COUNT(DISTINCT "Order ID") AS Average_Order_Value FROM superstore;