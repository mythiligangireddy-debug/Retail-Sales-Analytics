-- SALES ANALYSIS

SELECT strftime('%Y-%m',"Order Date") AS Month,SUM(Sales) AS Total_Sales FROM superstore GROUP BY strftime('%Y-%m',"Order Date") ORDER BY Month;
SELECT Category,SUM(Sales) AS Total_Sales FROM superstore GROUP BY Category ORDER BY Total_Sales DESC;
SELECT Category,SUM(Profit) AS Total_Profit FROM superstore GROUP BY Category ORDER BY Total_Profit DESC;
SELECT Segment,SUM(Sales) AS Total_Sales FROM superstore GROUP BY Segment ORDER BY Total_Sales DESC;
SELECT Segment,SUM(Profit) AS Total_Profit FROM superstore GROUP BY Segment ORDER BY Total_Profit DESC;
SELECT "Ship Mode",SUM(Sales) AS Total_Sales FROM superstore GROUP BY "Ship Mode" ORDER BY Total_Sales DESC;