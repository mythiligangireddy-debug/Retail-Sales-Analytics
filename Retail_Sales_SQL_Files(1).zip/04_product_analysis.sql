-- PRODUCT ANALYSIS

SELECT "Product Name",SUM(Sales) AS Total_Sales FROM superstore GROUP BY "Product Name" ORDER BY Total_Sales DESC LIMIT 10;
SELECT "Product Name",SUM(Profit) AS Total_Profit FROM superstore GROUP BY "Product Name" ORDER BY Total_Profit LIMIT 10;
SELECT "Sub-Category",SUM(Sales) AS Total_Sales FROM superstore GROUP BY "Sub-Category" ORDER BY Total_Sales DESC LIMIT 10;
SELECT "Sub-Category",SUM(Profit) AS Total_Profit FROM superstore GROUP BY "Sub-Category" ORDER BY Total_Profit LIMIT 10;
SELECT Category,AVG(Discount) AS Average_Discount FROM superstore GROUP BY Category ORDER BY Average_Discount DESC;
SELECT Category,AVG(Profit) AS Average_Profit FROM superstore GROUP BY Category ORDER BY Average_Profit DESC;