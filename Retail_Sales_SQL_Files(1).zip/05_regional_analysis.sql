-- REGIONAL ANALYSIS

SELECT Region,SUM(Sales) AS Total_Sales FROM superstore GROUP BY Region ORDER BY Total_Sales DESC;
SELECT Region,SUM(Profit) AS Total_Profit FROM superstore GROUP BY Region ORDER BY Total_Profit DESC;
SELECT State,SUM(Sales) AS Total_Sales FROM superstore GROUP BY State ORDER BY Total_Sales DESC;
SELECT State,SUM(Profit) AS Total_Profit FROM superstore GROUP BY State HAVING SUM(Profit)<0 ORDER BY Total_Profit;