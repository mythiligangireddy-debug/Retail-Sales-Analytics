-- ADVANCED SQL

SELECT Month,Total_Sales,SUM(Total_Sales) OVER(ORDER BY Month) AS Running_Total FROM (SELECT strftime('%Y-%m',"Order Date") AS Month,SUM(Sales) AS Total_Sales FROM superstore GROUP BY Month);