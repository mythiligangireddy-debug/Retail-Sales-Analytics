-- CUSTOMER ANALYSIS

SELECT "Customer Name",SUM(Sales) AS Total_Sales FROM superstore GROUP BY "Customer Name" ORDER BY Total_Sales DESC LIMIT 10;
SELECT AVG(Customer_Sales) AS Average_Sales_Per_Customer FROM (SELECT "Customer ID",SUM(Sales) AS Customer_Sales FROM superstore GROUP BY "Customer ID");
SELECT "Customer Name",SUM(Sales) AS Total_Sales,RANK() OVER(ORDER BY SUM(Sales) DESC) AS Customer_Rank FROM superstore GROUP BY "Customer Name";